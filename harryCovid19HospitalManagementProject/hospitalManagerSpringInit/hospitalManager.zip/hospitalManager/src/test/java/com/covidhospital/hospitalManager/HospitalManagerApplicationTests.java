package com.covidhospital.hospitalManager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
